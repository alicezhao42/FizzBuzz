// Your solution to MIE250 Project 1 goes here
// This is the "default package" hence there should be *no* line that starts with "package ...;"

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class FizzBuzz {
	public static BufferedReader cin = new BufferedReader(new InputStreamReader(System.in));
	
	public static void main(String[] args) throws NumberFormatException, IOException {
		boolean a = true; //value used to repeat program, a will always be true until zero is put in
		do { 
			System.out.println("   JAVA FIZZBUZZ PROGRAM");

			System.out.print("Enter Fizz number: "); 
			int fizz = checkNumber(); 
			
			if (fizz == 0) { 
				a = false;
				System.out.println("\nThe end.");
				System.exit(0); //exits the system when the fizz number is 0
			}
	
			System.out.print("Enter Buzz number: ");
			int buzz = checkNumber(); 
			
			if (buzz == 0) { 
				a = false; 
				System.out.println("\nThe end.");
				System.exit(0);
			}
		
			System.out.print("Enter starting number: ");
			int start = Integer.parseInt(cin.readLine());
		
			System.out.print("Enter ending number: ");
			int last = Integer.parseInt(cin.readLine());
		
			boolean values; 
		
			do {
				values = true; 
			
				if (last < start) {
					values = false;
					System.out.print("ERROR: Ending number cannot be less than starting number! Try again: ");
					last = Integer.parseInt(cin.readLine());
				}
			} while (!values); 
		
			System.out.println(""); 
			
			for (int j = start; j <= last; j++) {
				if (j % fizz == 0 && j % buzz == 0)	{
					System.out.println(j + ". FizzBuzz");
				} else if (j % fizz == 0 && j % buzz != 0) {
					System.out.println(j + ". Fizz");
				} else if (j % fizz != 0 && j % buzz == 0) {
					System.out.println(j + ". Buzz");
				} else {
					System.out.println(j + ". " + j);
				}	
			}
			System.out.println(""); 
		} while(a); 
	}
	
	public static int checkNumber() throws NumberFormatException, IOException {
		int num = 0; 
		boolean value;
		
		do {
			value = true;
			num = Integer.parseInt(cin.readLine());

			if (num < 0) {
				value = false; 
				System.out.print("ERROR: Negative numbers are not allowed! Try again: ");
			}
		} while (!value);
		return num; 
	}
}

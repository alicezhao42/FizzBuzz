# MIE250 Project1

Please see the assignment description posted on Quercus for instructions.
